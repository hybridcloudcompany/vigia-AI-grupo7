package com.example.monitored_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonitoredServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonitoredServiceApplication.class, args);
	}

}
